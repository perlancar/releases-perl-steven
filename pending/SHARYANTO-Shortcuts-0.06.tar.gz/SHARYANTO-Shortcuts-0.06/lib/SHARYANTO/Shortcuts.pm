package SHARYANTO::Shortcuts;

our $VERSION = '0.06'; # VERSION

1;
# ABSTRACT: Steven's shortcut modules

__END__

=pod

=encoding UTF-8

=head1 NAME

SHARYANTO::Shortcuts - Steven's shortcut modules

=head1 VERSION

This document describes version 0.06 of module SHARYANTO::Shortcuts (in distribution SHARYANTO-Shortcuts), released on 2014-05-01.

=head1 DESCRIPTION

This distribution contains shortcut names for various modules that I often use,
mostly for one-liners. It does not reside on CPAN, for obvious reason. Instead,
I put it on my personal DarkPAN. You can install it with:

 % cpanm --mirror https://github.com/sharyanto/darkpan-steven/raw/master/ --mirror-only SHARYANTO::Shortcuts

=head1 SEE ALSO

L<SHARYANTO>

=head1 BUGS

Please report all bug reports or feature requests to L<mailto:stevenharyanto@gmail.com>.

=head1 SOURCE

Source repository is at L<https://github.com/sharyanto/SHARYANTO-Shortcuts>.

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2014 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
