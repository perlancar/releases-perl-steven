package DD;

our $VERSION = '0.05'; # VERSION

BEGIN { require Data::Dump }
use Data::Dump (@Data::Dump::EXPORT,
                @Data::Dump::EXPORT_OK);

our @ISA = qw(Exporter);
our @EXPORT    = (@Data::Dump::EXPORT, "dump");
our @EXPORT_OK = @Data::Dump::EXPORT_OK;

1;
# ABSTRACT: Shortcut for Data::Dump

__END__

=pod

=encoding UTF-8

=head1 NAME

DD - Shortcut for Data::Dump

=head1 VERSION

version 0.05

=head1 SYNOPSIS

 % perl -MDD -E'dd $my_data'

=head1 DESCRIPTION

It imports all Data::Dump's exports. It also exports C<dump> by default, so
you can do:

 die dump $data;

=head1 FUNCTIONS


None are exported by default, but they are exportable.

=head1 SEE ALSO

L<DD>

=head1 BUGS

Please report all bug reports or feature requests to L<mailto:stevenharyanto@gmail.com>.

=head1 SOURCE

Source repository is at L<https://github.com/sharyanto/SHARYANTO-Shortcuts>.

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2013 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
