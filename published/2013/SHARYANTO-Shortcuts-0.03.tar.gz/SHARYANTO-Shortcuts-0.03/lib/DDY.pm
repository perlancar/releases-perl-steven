package DDY;

use 5.010001;
use YAML::Syck;

our $VERSION = '0.03'; # VERSION

require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(dd);

sub dd {
    say Dump(shift);
}

1;
# ABSTRACT: Dump as JSON, with Data::Dump-like interface

__END__

=pod

=encoding utf-8

=head1 NAME

DDY - Dump as JSON, with Data::Dump-like interface

=head1 SYNOPSIS

 % perl -MDDJ -E'dd $my_data'

=head1 FUNCTIONS

=head2 dd

=head1 SEE ALSO

L<DD>

=head1 BUGS

Please report all bug reports or feature requests to L<mailto:stevenharyanto@gmail.com>.

=head1 SOURCE

Source repository is at L<https://github.com/sharyanto/SHARYANTO-Shortcuts>.

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2013 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
