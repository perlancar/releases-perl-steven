package yaml;

use YAML::Syck;

our $VERSION = '0.02'; # VERSION

require Exporter;
our @ISA = qw(Exporter);
our @EXPORT = qw(from_yaml to_yaml);

sub from_yaml {
    Load(shift);
}

sub to_yaml {
    Dump(shift);
}

1;
# ABSTRACT: JSON.pm-like interface to parse and dump YAML

__END__

=pod

=encoding utf-8

=head1 NAME

yaml - JSON.pm-like interface to parse and dump YAML

=head1 SYNOPSIS

 % perl -Myaml -E'say to_yaml($data)'
 % perl -Myaml -E'$data = from_yaml("...")'

=head1 DESCRIPTION

JSON exports C<from_json> and C<to_json> by default. This module mimics is the
YAML counterpart of that. It currently uses L<YAML::Syck>.

=head1 AVAILABILITY

The latest version of this module is available from the Comprehensive Perl
Archive Network (CPAN). Visit L<http://www.perl.com/CPAN/> to find a CPAN
site near you, or see L<https://metacpan.org/module/SHARYANTO::Shortcuts/>.

=head1 BUGS

Please report any bugs or feature requests to bug-sharyanto-shortcuts@rt.cpan.org or through the web interface at:
 http://rt.cpan.org/Public/Dist/Display.html?Name=SHARYANTO-Shortcuts

=head1 FUNCTIONS

=head2 from_yaml($str) => $data

Exported by default.

=head2 to_yaml($str) => $data

Exported by default.

=head1 SEE ALSO

L<DDY>

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2013 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
