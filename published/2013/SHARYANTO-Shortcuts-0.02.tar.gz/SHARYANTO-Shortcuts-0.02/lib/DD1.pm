package DD1;

our $VERSION = '0.02'; # VERSION

use Data::Dump::OneLine (@Data::Dump::OneLine::EXPORT,
                         @Data::Dump::OneLine::EXPORT_OK);

our @ISA = qw(Exporter);
our @EXPORT    = (@Data::Dump::OneLine::EXPORT, "dd");
our @EXPORT_OK = @Data::Dump::OneLine::EXPORT_OK;

*dd = \*dump1;

1;
# ABSTRACT: Shortcut for Data::Dump::OneLine

__END__

=pod

=encoding utf-8

=head1 NAME

DD1 - Shortcut for Data::Dump::OneLine

=head1 SYNOPSIS

 % perl -MDD1 -E'dd $my_data'

=head1 DESCRIPTION

It exports C<dd> which is an alias for C<dump1>.

=head1 AVAILABILITY

The latest version of this module is available from the Comprehensive Perl
Archive Network (CPAN). Visit L<http://www.perl.com/CPAN/> to find a CPAN
site near you, or see L<https://metacpan.org/module/SHARYANTO::Shortcuts/>.

=head1 BUGS

Please report any bugs or feature requests to bug-sharyanto-shortcuts@rt.cpan.org or through the web interface at:
 http://rt.cpan.org/Public/Dist/Display.html?Name=SHARYANTO-Shortcuts

=for Pod::Coverage ^(dd)$

=head1 SEE ALSO

L<DD>

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2013 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
