package FS;

our $DATE = '2015-06-19'; # DATE
our $VERSION = '0.13'; # VERSION

# we do this first to get @EXPORT_OK
BEGIN { require File::Slurper }

# then we import
use File::Slurper @File::Slurper::EXPORT_OK;

our @ISA = qw(Exporter);
our @EXPORT_OK = @File::Slurper::EXPORT_OK;
our @EXPORT = @EXPORT_OK;

1;
# ABSTRACT: Shortcut for File::Slurper

__END__

=pod

=encoding UTF-8

=head1 NAME

FS - Shortcut for File::Slurper

=head1 VERSION

This document describes version 0.13 of FS (from Perl distribution SHARYANTO-Shortcuts), released on 2015-06-19.

=head1 SYNOPSIS

 % perl -MFS -E'$content = read_text("blah.txt")'

=head1 DESCRIPTION

In addition to the short name, FS also imports all File::Slurper routines by
default (read_text, write_text, read_binary, write_binary, et al).

=head1 BUGS

Please report all bug reports or feature requests to L<mailto:stevenharyanto@gmail.com>.=head1 SOURCE

Source repository is at L<https://github.com/sharyanto/SHARYANTO-Shortcuts>.=head1 AUTHOR

Steven Haryanto

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2015 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
