package DD;

our $DATE = '2015-06-19'; # DATE
our $VERSION = '0.13'; # VERSION

# we need this first to get @Data::Dump::EXPORT et al
BEGIN { require Data::Dump }

# then we import
use Data::Dump (@Data::Dump::EXPORT_OK);

our @ISA = qw(Exporter);
our @EXPORT    = (@Data::Dump::EXPORT, "dump");
our @EXPORT_OK = @Data::Dump::EXPORT_OK;

sub dd  { Data::Dump::dd( @_); wantarray ? @_ : $_[0] }
sub ddx { Data::Dump::ddx(@_); wantarray ? @_ : $_[0] }

1;
# ABSTRACT: Shortcut for Data::Dump

__END__

=pod

=encoding UTF-8

=head1 NAME

DD - Shortcut for Data::Dump

=head1 VERSION

This document describes version 0.13 of DD (from Perl distribution SHARYANTO-Shortcuts), released on 2015-06-19.

=head1 SYNOPSIS

 % perl -MDD -E'dd $my_data'

=head1 DESCRIPTION

It imports all Data::Dump's exports. It also exports C<dump> by default, so you
can do:

 die dump $data;

In addition, it also changes dd() and ddx() to return the original arguments, so
they can be inserted into expressions.

=for Pod::Coverage .+

=head1 SEE ALSO

L<DD>

=head1 BUGS

Please report all bug reports or feature requests to L<mailto:stevenharyanto@gmail.com>.=head1 SOURCE

Source repository is at L<https://github.com/sharyanto/SHARYANTO-Shortcuts>.=head1 AUTHOR

Steven Haryanto

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2015 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
