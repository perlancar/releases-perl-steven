package FS;

# we do this first to get @EXPORT_OK
BEGIN { require File::Slurp::Tiny }

# then we import
use File::Slurp::Tiny @File::Slurp::Tiny::EXPORT_OK;

our @ISA = qw(Exporter);
our @EXPORT_OK = @File::Slurp::Tiny::EXPORT_OK;
our @EXPORT = qw(read_file write_file);

our $VERSION = '0.07'; # VERSION
our $DATE = '2014-05-27'; # DATE

1;
# ABSTRACT: Shortcut for File::Slurp::Tiny

__END__

=pod

=encoding UTF-8

=head1 NAME

FS - Shortcut for File::Slurp::Tiny

=head1 VERSION

This document describes version 0.07 of module FS (in distribution SHARYANTO-Shortcuts), released on 2014-05-27.

=head1 SYNOPSIS

 % perl -MFS -E'$content = read_file("blah.txt")'

=head1 DESCRIPTION

In addition to the short name, FS also imports C<read_file> and C<write_files>
by default.

=head1 BUGS

Please report all bug reports or feature requests to L<mailto:stevenharyanto@gmail.com>.

=head1 SOURCE

Source repository is at L<https://github.com/sharyanto/SHARYANTO-Shortcuts>.

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2014 by Steven Haryanto.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
