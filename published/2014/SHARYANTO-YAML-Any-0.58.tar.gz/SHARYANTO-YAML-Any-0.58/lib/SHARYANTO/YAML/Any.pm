package SHARYANTO::YAML::Any_SyckOnly;
package SHARYANTO::YAML::Any;

# NOTE: temporary namespace, will eventually be refactored, tidied up, and sent
# to a more proper namespace.

use 5.010001;
use strict;
use Exporter ();

our @ISA       = qw(Exporter);
our @EXPORT    = qw(Dump Load);
our @EXPORT_OK = qw(DumpFile LoadFile);

our $VERSION   = '0.72';

use YAML::Syck;
$YAML::Syck::ImplicitTyping = 1;

1;
# ABSTRACT: Pick a YAML implementation and use it

__END__

=pod

=encoding UTF-8

=head1 NAME

SHARYANTO::YAML::Any_SyckOnly - Pick a YAML implementation and use it

=head1 VERSION

version 0.58

=for Pod::Coverage .*

=head1 SEE ALSO

L<SHARYANTO>

=head1 AUTHOR

Steven Haryanto <stevenharyanto@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2014 by Steven Haryanto.  No
license is granted to other entities.

=cut
